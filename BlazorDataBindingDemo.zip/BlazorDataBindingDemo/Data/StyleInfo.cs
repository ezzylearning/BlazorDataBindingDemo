﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BlazorDataBindingDemo.Data
{
    public class StyleInfo
    {
        public string Name { get; set; }
        public string CssClass { get; set; }
    }
}
